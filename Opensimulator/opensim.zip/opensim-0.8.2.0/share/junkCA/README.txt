This Folder contains junk CA files and directions for signing with it.
Comply with export laws!
